# init_tables.py
import mysql_wb  # your existing MySQL helper module
from mysql_wb import q, get_conn, ensure_database

def reset_tables():
    ensure_database()
    conn = get_conn()
    c = conn.cursor()

    # Drop in correct dependency order to avoid foreign key errors
    tables = [
        "messages",
        "pending_messages",
        "offline_users",
        "online_users",
        "users"
    ]
    for table in tables:
        c.execute(f"DROP TABLE IF EXISTS {table}")

    # Recreate tables exactly as in ensure_tables()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username VARCHAR(255) PRIMARY KEY,
            salt VARBINARY(16),
            hash VARBINARY(64),
            public_key BLOB,
            signing_public_key BLOB
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS online_users (
            username VARCHAR(255) PRIMARY KEY,
            ip_address VARCHAR(255) NOT NULL,
            port INT NOT NULL,
            updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ON UPDATE CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS offline_users (
            username VARCHAR(255) PRIMARY KEY,
            last_offline TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ON UPDATE CURRENT_TIMESTAMP
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS pending_messages (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            recipient VARCHAR(255) NOT NULL,
            sender VARCHAR(255) NOT NULL,
            msg_type ENUM('text','file') NOT NULL,
            payload MEDIUMBLOB NOT NULL,
            delivered TINYINT(1) DEFAULT 0,
            queued_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX(recipient),
            INDEX(delivered)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            msg_id VARCHAR(64) PRIMARY KEY,
            sender VARCHAR(255) NOT NULL,
            recipient VARCHAR(255) NOT NULL,
            ts BIGINT NOT NULL,
            dir ENUM('in','out') NOT NULL,
            pfs TINYINT(1) DEFAULT 0,
            eph_pub_base64 TEXT,
            nonce_base64 TEXT NOT NULL,
            tag_base64 TEXT NOT NULL,
            ct_base64 LONGTEXT NOT NULL,
            signature_base64 TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()
    print("✅ Tables reset and recreated successfully.")

if __name__ == "__main__":
    reset_tables()
